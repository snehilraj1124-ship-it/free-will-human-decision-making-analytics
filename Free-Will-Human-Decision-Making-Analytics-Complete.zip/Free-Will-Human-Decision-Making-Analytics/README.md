# Free Will & Human Decision-Making Analytics

> An interdisciplinary data analytics project exploring human decision-making, perceived agency, behavioral constraints, and philosophical perspectives on free will using synthetic data.

## 📌 Project Overview

**Free Will & Human Decision-Making Analytics** explores the relationship between human decision-making behavior and philosophical ideas surrounding free will, agency, determinism, and personal responsibility.

The project combines:

- Behavioral analytics
- Philosophy of mind
- Data analytics
- Statistics
- Machine learning
- Decision science

A synthetic dataset containing **1,000 simulated decision cases** is analyzed across career, financial, relationship, health, education, and consumer decisions.

The goal is not to prove whether free will exists. Instead, the project demonstrates how concepts such as **perceived agency, self-control, cognitive reflection, social influence, stress, and emotional intensity** can be structured and analyzed quantitatively.

## 🎯 Objectives

1. Analyze factors associated with human decision-making.
2. Study perceived agency and decision autonomy.
3. Examine internal and external constraints on decisions.
4. Investigate relationships between stress, reflection, social influence, and confidence.
5. Construct analytical decision-making indices.
6. Apply statistical analysis and machine learning.
7. Compare behavioral observations with philosophical perspectives.
8. Demonstrate responsible interpretation of psychologically themed data.

## 🧠 Philosophical Perspectives

### Libertarian Free Will
Emphasizes genuine alternative possibilities and meaningful authorship of choices.

### Hard Determinism
Emphasizes causal factors and challenges the idea that choices are ultimately free.

### Compatibilism
Explores the possibility that meaningful freedom can coexist with causal determination when actions reflect an individual's reasons and values.

### Uncertainty
Some philosophical questions cannot be resolved through behavioral data alone. This project therefore treats philosophy as an interpretive framework rather than a prediction target.

## 📊 Dataset

The project contains **1,000 synthetic decision cases**.

Key variables include:

| Variable | Description |
|---|---|
| `decision_type` | Type of decision |
| `context` | Decision stakes |
| `personality_style` | Analytical, intuitive, or balanced |
| `time_pressure` | Perceived time pressure |
| `information_quality` | Quality of available information |
| `sleep_hours` | Simulated sleep duration |
| `stress_score` | Stress level, 0–100 |
| `self_control_score` | Self-control, 0–100 |
| `cognitive_reflection_score` | Reflective reasoning, 0–100 |
| `emotional_intensity_score` | Emotional intensity, 0–100 |
| `social_influence_score` | Social influence, 0–100 |
| `decision_confidence_score` | Decision confidence, 0–100 |
| `perceived_agency_score` | Perceived control over decision, 0–100 |
| `regret_score` | Regret indicator, 0–100 |
| `decision_satisfaction_score` | Decision satisfaction, 0–100 |

## 📐 Analytical Indices

### Decision Autonomy Index

```text
35% Perceived Agency
25% Self-Control
20% Cognitive Reflection
20% Inverse Social Influence
```

### Decision Quality Index

The project combines cognitive reflection, information quality, self-control, confidence, satisfaction, and a stress adjustment.

### Constraint Pressure Index

Combines:

- Stress
- Social influence
- Time pressure
- Emotional intensity

### Agency-Adjusted Confidence

Combines decision confidence with perceived autonomy.

### Regret Risk Index

Combines regret, stress, emotional intensity, and low decision satisfaction.

These indices are **project-specific analytical constructs**, not validated psychological instruments.

## 🔬 Analysis Workflow

```text
Synthetic Data
      ↓
Data Cleaning
      ↓
Exploratory Data Analysis
      ↓
Descriptive Statistics
      ↓
Correlation Analysis
      ↓
Feature Engineering
      ↓
Hypothesis Testing
      ↓
Regression Analysis
      ↓
K-Means Clustering
      ↓
Visualization
      ↓
Philosophical Interpretation
```

## 🧪 Statistical Analysis

The project can examine relationships such as:

- Perceived agency vs decision confidence
- Stress vs autonomy
- Social influence vs autonomy
- Information quality vs decision quality
- Reflection vs decision satisfaction
- Constraint pressure vs regret risk

Example hypothesis:

```text
H₀: Perceived agency is not associated with decision confidence.

H₁: Perceived agency is associated with decision confidence.
```

## 🤖 Machine Learning

### K-Means Clustering

K-Means clustering is used to identify exploratory decision-making profiles based on behavioral variables.

Possible profiles may include:

- High-agency decision makers
- Constraint-heavy decision makers
- Emotionally influenced decision makers
- Reflection-oriented decision makers

The clusters are exploratory and should not be treated as psychological diagnoses or fixed personality types.

## 📈 Visualizations

The project supports:

- Distribution plots
- Box plots
- Correlation heatmaps
- Scatter plots
- Scenario comparisons
- Agency segment comparisons
- Cluster visualizations

## 📁 Project Structure

```text
Free-Will-Human-Decision-Making-Analytics/
│
├── data/
│   ├── raw/
│   │   └── free_will_decision_cases.csv
│   └── processed/
│       └── processed_decision_cases.csv
│
├── notebooks/
│   ├── 01_exploratory_analysis.ipynb
│   └── 02_agency_machine_learning.ipynb
│
├── src/
│   ├── data_generation.py
│   ├── feature_engineering.py
│   ├── statistical_analysis.py
│   ├── clustering.py
│   └── visualization.py
│
├── docs/
├── reports/
├── visualizations/
├── config/
├── tests/
├── requirements.txt
├── LICENSE
└── README.md
```

## 🛠️ Technology Stack

- Python
- Pandas
- NumPy
- SciPy
- Scikit-learn
- Matplotlib
- Seaborn
- Jupyter Notebook
- Git & GitHub

## ⚙️ Installation

```bash
git clone https://github.com/YOUR-USERNAME/free-will-human-decision-making-analytics.git
cd free-will-human-decision-making-analytics
python -m venv venv
```

### Windows

```bash
venv\Scripts\activate
```

### macOS/Linux

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Launch Jupyter:

```bash
jupyter notebook
```

## 🔍 Research Questions

1. How strongly is perceived agency associated with decision confidence?
2. Does social influence correspond with lower decision autonomy?
3. How does stress relate to decision quality?
4. Does information quality correspond with better decision outcomes?
5. Can clustering identify recurring decision-making patterns?
6. How can philosophical theories provide different interpretations of the same behavioral data?

## 🌍 Potential Applications

The analytical concepts can be relevant to:

- Behavioral analytics
- Decision science
- Human-AI interaction
- Product design
- Consumer behavior
- Management research
- Organizational decision-making
- Responsible AI
- Human-centered technology

## ⚠️ Ethics & Responsible Use

This project uses **fully synthetic data**.

It should not be used to:

- Diagnose psychological conditions
- Determine whether a real person has free will
- Assess someone's moral responsibility
- Make employment or medical decisions
- Predict individual behavior in high-stakes settings
- Label individuals based on behavioral scores

Free will is a complex philosophical concept, and numerical indices cannot establish whether free will objectively exists.

## 🚧 Limitations

- Dataset is synthetic.
- Behavioral variables are simulated rather than clinically validated.
- Composite index weights are assumptions.
- Correlation does not imply causation.
- K-Means clusters are exploratory.
- Philosophical theories contain nuances that cannot be completely represented numerically.
- Human decision-making is influenced by culture, environment, history, relationships, and context.

## 🔮 Future Scope

Future versions could include:

- Real-world behavioral experiments
- Longitudinal decision studies
- Causal inference
- Explainable AI
- NLP analysis of philosophical arguments
- Human-vs-AI decision comparisons
- Interactive Streamlit dashboard
- Cross-cultural decision research
- Decision simulation engine
- Human-in-the-loop AI systems

## 💼 Portfolio Value

This project demonstrates the intersection of:

```text
Psychology
    +
Philosophy
    +
Data Analytics
    +
Statistics
    +
Machine Learning
    +
Decision Science
```

It is particularly relevant for portfolios targeting **Data Analytics, Business Analytics, AI, Management, Technology Management, and Responsible AI**.

## 👤 Author

**Snehil Raj**

B.Tech Electrical & Electronics Engineering  
Data Analytics | AI | Business & Technology

## 📄 License

This project is released under the MIT License.

---

⭐ If you find the project interesting, explore the notebooks, methodology, analytical indices, and philosophical framework documentation.
