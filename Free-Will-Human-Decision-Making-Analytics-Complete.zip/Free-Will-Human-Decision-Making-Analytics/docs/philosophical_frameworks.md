# Philosophical Frameworks

## Libertarian Free Will
Treats meaningful free choice as requiring alternatives and genuine authorship.

## Hard Determinism
Emphasizes causal determination and questions whether choices are ultimately free.

## Compatibilism
Argues that meaningful freedom can coexist with causal determination when actions reflect an agent's internal reasons and values.

## Analytical Note
The project does not attempt to prove any philosophical position. It operationalizes selected concepts to demonstrate data analysis.
