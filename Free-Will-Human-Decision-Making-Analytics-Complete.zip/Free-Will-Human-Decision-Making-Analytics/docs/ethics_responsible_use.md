# Ethics & Responsible Use

This project uses synthetic data and is educational. It must not be used to diagnose individuals, infer actual free will, make employment/medical/financial decisions, or label people as morally responsible based on numerical scores.

Do not treat perceived agency or behavioral scores as clinical or psychological assessments.
