# Future Scope

- Longitudinal decision studies
- Behavioral experiment data
- Explainable ML
- Causal inference
- NLP analysis of philosophical arguments
- Interactive Streamlit dashboard
- Cross-cultural decision research
- Human-AI decision comparison
