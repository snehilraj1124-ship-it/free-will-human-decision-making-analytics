# Data README

The repository contains 1,000 simulated decision cases generated with a fixed random seed. No real participants are represented. All behavioral and philosophical variables are synthetic.
