# Interview Notes

### Explain the project in 30 seconds
I built a synthetic decision-making analytics system that connects behavioral data with philosophy of free will. I created indices for perceived agency, decision quality, constraint pressure and regret risk, then applied statistics and K-Means clustering to identify patterns.

### Why synthetic data?
To demonstrate the analytical workflow without collecting or exposing personal psychological information.

### Main caveat?
Free will is not directly measurable through a numerical index; the scores are analytical abstractions.
