# Methodology

1. Generate a synthetic dataset of 1,000 simulated decision cases.
2. Clean and validate variables.
3. Explore distributions and relationships.
4. Construct analytical indices.
5. Perform correlation and group analysis.
6. Apply regression and K-Means clustering.
7. Interpret patterns with philosophical context.

The numerical indices are project-specific abstractions, not validated psychological instruments.
