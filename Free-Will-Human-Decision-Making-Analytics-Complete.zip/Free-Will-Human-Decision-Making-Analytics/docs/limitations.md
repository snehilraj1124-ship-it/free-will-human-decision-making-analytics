# Limitations

- Synthetic rather than observed human data.
- Free will is a philosophical concept that cannot be directly measured by a single score.
- Composite weights are assumptions created for demonstration.
- Correlation does not imply causation.
- Clustering is exploratory.
- Cultural and contextual differences are not fully represented.
