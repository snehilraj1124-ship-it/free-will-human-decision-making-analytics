# Visualization utilities for decision-making and agency analysis.
