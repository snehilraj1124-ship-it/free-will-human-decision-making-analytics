# Feature engineering
# Builds Decision Autonomy, Decision Quality, Constraint Pressure,
# Agency-Adjusted Confidence and Regret Risk indices.
