# Synthetic data generation script
# The repository includes the generated dataset for reproducibility.
# Random seed: 42
