# Results Template

Use this file to record:
- Descriptive statistics
- Correlation findings
- Hypothesis-test results
- Regression coefficients
- Cluster profiles
- Scenario comparisons
- Limitations and interpretation
