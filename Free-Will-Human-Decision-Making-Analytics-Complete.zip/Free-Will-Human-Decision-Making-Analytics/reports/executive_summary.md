# Executive Summary

This project studies decision-making through the combined lens of behavioral analytics and philosophy of free will. It creates analytical indices for agency, decision quality, constraint pressure, confidence, and regret risk, then uses statistical analysis and clustering to explore recurring patterns.

The results are illustrative because the underlying data are synthetic.
