# Research Questions

1. How are perceived agency and decision confidence related?
2. How do stress and social influence relate to perceived autonomy?
3. Does information quality correspond with decision quality?
4. Can behavioral variables reveal recurring decision profiles?
5. How can philosophical perspectives frame the same behavioral observations differently?
