import pandas as pd

def test_dataset_shape():
    df = pd.read_csv("data/processed/processed_decision_cases.csv")
    assert len(df) == 1000

def test_scores_in_range():
    df = pd.read_csv("data/processed/processed_decision_cases.csv")
    cols = [c for c in df.columns if c.endswith("_score")] + [
        "decision_autonomy_index","decision_quality_index",
        "constraint_pressure_index","agency_adjusted_confidence","regret_risk_index"
    ]
    for c in cols:
        assert df[c].between(0,100).all()
